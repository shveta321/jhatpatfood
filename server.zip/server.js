const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require("fs");             // ✅ ADD THIS
const multer = require("multer");     // ✅ ADD THIS

const app = express();
const PORT = 5000;


// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// MySQL connection (single connection for 'jhatpat')
const db = mysql.createConnection({
  host: 'localhost',
  port: 3307,
  user: 'root',
  password: '',
  database: 'jhatpat'
});

// Connect to database
db.connect(err => {
  if (err) {
    console.error('❌ DB connection failed:', err);
    process.exit();
  } else {
    console.log('✅ Connected to jhatpat database');
  }
});

// API endpoint for contact form
app.post('/api/contact', (req, res) => {
  const { name, email, phone, country, postalCode, inquiry } = req.body;

  if (!name || !email || !phone || !inquiry) {
    return res.status(400).json({ message: 'Required fields missing!' });
  }

  const query = `
    INSERT INTO contact_us 
    (name, email, phone, country, postal_code, message) 
    VALUES (?, ?, ?, ?, ?, ?)
  `;
  const values = [name, email, phone, country, postalCode, inquiry];

  db.query(query, values, (err, result) => {
    if (err) {
      console.error('❌ Error saving contact:', err);
      return res.status(500).json({ message: 'Server error' });
    }
    res.status(200).json({ message: '✅ Message sent successfully!' });
  });
});

// Serve static files if needed (frontend files)
app.use(express.static(path.join(__dirname, '../frontend')));



// Backend: Static image serving
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Multer config
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads"),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname)),
});
const upload = multer({ storage });

// Upload route
app.post("/upload", upload.single("photo"), (req, res) => {
  const filename = req.file.filename;
  db.query("REPLACE INTO todaymenu (id, filename) VALUES (?, ?)", [1, filename], (err) => {
    if (err) return res.status(500).json({ error: "DB error" });
    res.json({ filename });
  });
});

// Get today menu
app.get("/todaymenu", (req, res) => {
  db.query("SELECT filename FROM todaymenu WHERE id = 1", (err, result) => {
    if (err) return res.status(500).json({ error: "DB error" });
    if (result.length > 0) {
      res.json({ filename: result[0].filename });
    } else {
      res.json({ filename: null });
    }
  });
});





// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running at: http://localhost:${PORT}`);
});

