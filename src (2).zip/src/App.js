import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import Header from './components/Header';
import Apfooter from './components/Apfooter';
import Homes from './components/Homes';
import Abouts from './components/Abouts';
import User from './components/User';
import Services from './components/Services';
import Event from './components/Event';
import BookUs from './components/BookUs';
import ChefTeam from './components/ChefTeam';
import Menus from './components/Menus';
import Breakfast from './pages/Breakfast';
import Order from './pages/Order';
import Lunch from "./pages/Lunch";
import Contact from './components/Contact';
import DailyMenu from './components/DailyMenu';
import Uploadmenu from "./components/Dashboard/Uploadmenu";
import Dash_home from './components/Dashboard/Dash_home';
import Login from "./components/Login";
import ProtectedRoute from "./components/ProtectedRoute";
import UploadBreakfast from './components/Dashboard/UploadBreakfast';
import Dashboard from './components/Dashboard/Dashboard';
import UploadLunch from './components/Dashboard/UplodeLunch';

function AppContent() {
  const location = useLocation();

  return (
    <>
      {location.pathname === '/' && (
        <>
          <Header />
          <Homes />
          <Abouts />
          <User />
          <Services />
          <Event />
          <Menus />
          <ChefTeam />
          <BookUs />
          <Apfooter />
        </>
      )}
      <Routes>
        {/* Public Routes */}
        <Route path="/about" element={<Abouts />} />
        <Route path="/user" element={<User />} />
        <Route path="/service" element={<Services />} />
        <Route path="/event" element={<Event />} />
        <Route path="/bookus" element={<BookUs />} />
        <Route path="/chefteam" element={<ChefTeam />} />
        <Route path="/menus" element={<Menus />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login />} />
        <Route path="/menu/breakfast" element={<Breakfast />} />
        <Route path="/order/:item" element={<Order />} />
        <Route path="/menu/lunch" element={<Lunch />} />
        <Route path="/todaymenu" element={<DailyMenu />} />

      
        <Route path="/dashHome" element={
          <ProtectedRoute><Dash_home /></ProtectedRoute>
        } />
<Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>}>

          <Route path="upload_breakfast" element={<UploadBreakfast />} />
          <Route path="upload_Lunch" element={<UploadLunch />} />
          <Route path="breakfast" element={<Breakfast />} />
          <Route path="lunch" element={<Lunch />} />
          <Route path="upload_menu" element={<Uploadmenu />} />
        </Route>
      </Routes>
    </>
  );
}

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;
