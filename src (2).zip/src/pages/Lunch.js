import  { useState, useEffect } from "react";
import "./Lunch.css";

const Lunch = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [formData, setFormData] = useState({});
  const [showAddress, setShowAddress] = useState(false);
  const [finalPrice, setFinalPrice] = useState(0);
  const [menuItems, setMenuItems] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/lunch-items")
      .then((res) => res.json())
      .then((data) => setMenuItems(data))
      .catch((err) => console.error("❌ Failed to fetch lunch items", err));
  }, []);

  const handleOrderClick = (item) => {
    setSelectedItem(item);
    setFinalPrice(item.price);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setFormData({});
    setShowAddress(false);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    const updatedData = { ...formData, [name]: value };

    if (name === "deliveryMethod") {
      setShowAddress(value === "Home Delivery");
    }

    if (name === "quantity") {
      const qty = parseInt(value, 10) || 1;
      setFinalPrice(qty * (selectedItem?.price || 100));
    }

    setFormData(updatedData);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(
      `Order placed!\nItem: ${selectedItem.name}\nName: ${formData.name}\nPhone: ${formData.phone}\nQty: ${formData.quantity}\nDelivery: ${formData.deliveryMethod}\nPayment: ${formData.paymentMethod}`
    );
    closeModal();
  };

  return (
    <>
      <h1 style={{ textAlign: "center", color: "orangered" }}>Lunch Menu</h1>
      <div className="menu-container">
        {menuItems.map((item) => (
          <div className="menu-item" key={item.id}>
            <img
              src={`http://localhost:5000/uploads/${item.photo}`}
              alt={item.name}
              style={{ width: "100%", height: "150px", objectFit: "cover", borderRadius: "8px" }}
            />
            <h3>{item.name}</h3>
            <p>{item.description}</p>
            <p><strong>₹{item.price}</strong></p>
            <button onClick={() => handleOrderClick(item)}>Order Now</button>
          </div>
        ))}
      </div>

      {isModalOpen && selectedItem && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={closeModal}>&times;</span>
            <h3>Order: {selectedItem.name}</h3>
            <form onSubmit={handleSubmit}>
              <label>Name:</label>
              <input type="text" name="name" required onChange={handleChange} />
              <label>Phone:</label>
              <input type="tel" name="phone" required pattern="[0-9]{10}" onChange={handleChange} />

              <div className="quan-deli">
                <div className="form-group">
                  <label>Quantity:</label>
                  <input type="number" name="quantity" min="1" required onChange={handleChange} />
                </div>
                <div className="form-group">
                  <label>Delivery Method:</label>
                  <select name="deliveryMethod" required onChange={handleChange}>
                    <option value="">--Select--</option>
                    <option value="Pickup">Pickup</option>
                    <option value="Home Delivery">Home Delivery</option>
                  </select>
                </div>
              </div>

              {showAddress && (
                <>
                  <div className="hous-numb">
                    <input type="text" name="houseNumber" required placeholder="House No." onChange={handleChange} />
                    <input type="text" name="street" required placeholder="Street/Gali" onChange={handleChange} />
                  </div>
                  <div className="pin-cit">
                    <input type="text" name="pincode" required pattern="[0-9]{6}" placeholder="Pincode" onChange={handleChange} />
                    <input type="text" name="city" required placeholder="City" onChange={handleChange} />
                  </div>
                  <input type="text" name="location" required placeholder="Location" onChange={handleChange} />
                </>
              )}

              <div className="pay-coup">
                <select name="paymentMethod" required onChange={handleChange}>
                  <option value="">--Select Payment--</option>
                  <option value="Cash on Delivery">Cash on Delivery</option>
                  <option value="UPI">UPI</option>
                  <option value="Card">Card</option>
                </select>
                <input type="text" name="couponCode" placeholder="Coupon Code" onChange={handleChange} />
              </div>

              <h5>Total Price: ₹{finalPrice}</h5>
              <button type="submit">Place Order</button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default Lunch;
