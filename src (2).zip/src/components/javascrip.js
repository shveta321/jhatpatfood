
// Modal and form logic
var modal = document.getElementById("myModal");
var btns = document.querySelectorAll(".order-button");
var closeBtn = document.getElementById("closeBtn");
var menuItemInput = document.getElementById("menuItem");

btns.forEach(function (btn) {
  btn.onclick = function (event) {
    event.preventDefault();
    menuItemInput.value = btn.getAttribute("data-item");
    modal.style.display = "flex";
  };
});

closeBtn.onclick = function () {
  modal.style.display = "none";
};

window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};

// ✅ Form submit handler with correct ID
document.getElementById("breakfastOrderForm").onsubmit = function (event) {
  event.preventDefault();

  const formData = new FormData(document.getElementById("breakfastOrderForm"));

  fetch("http://localhost:3000/api/breakfast", {
    method: "POST",
    body: formData
  })
    .then(response => response.json())
    .then(data => {
      alert("submitted successfully!");
      document.getElementById("breakfastOrderForm").reset(); // clear form
      modal.style.display = "none";
    })
    .catch(error => {
      console.error("Error:", error);
      alert("Failed to submit .");
    });
};