import React from 'react';
// import { Link } from 'react-router-dom';
import { Route } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheck } from '@fortawesome/free-solid-svg-icons';
import { faLocationDot } from '@fortawesome/free-solid-svg-icons';
import { faPhone } from '@fortawesome/free-solid-svg-icons';
import { faEnvelope } from '@fortawesome/free-solid-svg-icons';



function Apfooter() {
    return (
        <footer>
            <div className="container-fluid">
                <div className="container">
                    <div className="row mt-5">
                        {/* About Section */}
                        <div className="col-lg-3 col-md-3 col-sm-6 col-12 mb-4">
                            <div>
                                <h2>JhatpatServ</h2>
                                <p>
                                    JhatpatServ Delivering catering solutions for every occasion. From intimate gatherings
                                    to grand celebrations, we serve freshness and flavor at speed.
                                </p>
                            </div>
                        </div>

                        {/* Special Facilities */}
                        <div className="col-lg-3 col-md-3 col-sm-6 col-12 mb-4">
                            <div>
                                <h2>Special Facilities</h2>
                                <ul className="food-de">
                                    <li>      <FontAwesomeIcon icon={faCheck} className="text-warning" />
                                        Cheese Burger</li>
                                    <li>      <FontAwesomeIcon icon={faCheck} className="text-warning" />
                                        Sandwich</li>
                                    <li>      <FontAwesomeIcon icon={faCheck} className="text-warning" />
                                        Panner Burger</li>
                                    <li>      <FontAwesomeIcon icon={faCheck} className="text-warning" />
                                        Special Sweets</li>
                                </ul>
                            </div>
                        </div>

                        {/* Contact Info */}
                        <div className="col-lg-3 col-md-3 col-sm-6 col-12 mb-4">
                            <div>
                                <h2>Contact Us</h2>
                                <ul className="food-de">
                                    <li>      <FontAwesomeIcon icon={faLocationDot} className="text-warning" /> 123 Street, New York, USA</li>
                                    <li>
                                        <FontAwesomeIcon icon={faPhone} className="text-warning" /> (+012) 3456 7890 123
                                    </li>
                                    <li>
                                        <FontAwesomeIcon icon={faEnvelope} className="text-warning" /> info@example.com
                                    </li>                                    <li><i className="fa-solid fa-clock text-warning"></i> 24/7 Hours Service</li>
                                </ul>
                            </div>
                        </div>

                        {/* Social Gallery */}
                        <div className="col-lg-3 col-md-3 col-sm-6 col-12 mb-4">
                            <div>
                                <h2>Social Gallery</h2>
                                <div className="row">
                                    {["thali1.jpg", "thali4.jpg", "Blooming.jpg"].map((img, i) => (
                                        <div className="col-lg-4 col-md-4 col-sm-6 col-12" key={`top-${i}`}>
                                            <div>
                                                <img src={`/img/${img}`} alt="" width="90" height="80" className="rounded-circle" />
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                <div className="row mt-3">
                                    {["thali2.jpg", "thali6.jpg", "thali7.jpg"].map((img, i) => (
                                        <div className="col-lg-4 col-md-4 col-sm-6 col-12" key={`bottom-${i}`}>
                                            <div>
                                                <img src={`/img/${img}`} alt="" width="90" height="80" className="rounded-circle" />
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    );
}

export default Apfooter;
