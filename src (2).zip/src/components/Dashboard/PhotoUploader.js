import React, { useState } from "react";

const PhotoUploader = () => {
  const [photo, setPhoto] = useState(null);
  const [uploadedPhoto, setUploadedPhoto] = useState(null);

  const handlePhotoChange = (e) => {
    setPhoto(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!photo) return alert("Please select a photo");

    const formData = new FormData();
    formData.append("photo", photo);

    const token = localStorage.getItem("token"); // ✅ Get token from localStorage

    try {
      const res = await fetch("http://localhost:3000/upload", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`, // ✅ Send token in Authorization header
        },
        body: formData,
      });

      if (!res.ok) {
        const errorText = await res.text(); // Handle non-JSON error like "Unauthorized"
        throw new Error(errorText);
      }

      const data = await res.json();
      setUploadedPhoto(data.filename);
      alert("Photo uploaded successfully!");
      setPhoto(null);
    } catch (error) {
      console.error("Upload error:", error.message);
      alert("Error uploading photo: " + error.message);
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Upload Today's Menu</h2>
      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <input type="file" accept="image/*" onChange={handlePhotoChange} required />
        <button type="submit" style={{ marginLeft: "10px" }}>Upload</button>
      </form>
    </div>
  );
};

export default PhotoUploader;
