import React from 'react';
// import { Link } from 'react-router-dom';
import { Route } from 'react-router-dom';




function Event() {
    return (
        <section>
        <div className="container-fluid">
            <div className="container mt-5">
                <div className="wel-jhatp-2 ">
                    <small className="wel-jhat-2">Latest Events</small>
                </div>
                <p className="offe">Our Social & Professional Events Gallery</p>
                <div className="all-event">
                    <div className="wel-jhatp-2 mb-3">
                        <small className="wel-jhat-2">All Events</small>
                    </div>
                    <div className="wel-jhatp-2 mb-3">
                        <small className="wel-jhat-2">Wedding</small>
                    </div>
                    <div className="wel-jhatp-2 mb-3">
                        <small className="wel-jhat-2">Corporate</small>
                    </div>
                    <div className="wel-jhatp-2 mb-3">
                        <small className="wel-jhat-2">Latest Events</small>
                    </div>
                </div>
                <div className="row mt-5">
                    <div className="col-lg-3 col-md-3 col-sm-6 col-12 mb-4">
                        <div className="all-even-im text-center">
                            <img src="/img/allevent.jpg" alt="" className="rounded img-fluid" width="250" height="270" />
                        </div>
                    </div>
                    <div className="col-lg-3 col-md-3 col-sm-6 col-12 mb-4">
                        <div className="text-center">
                            <img src="/img/allevent1.jpg" alt="" className="rounded img-fluid" width="250" height="270" />
                        </div>
                    </div>
                    <div className="col-lg-3 col-md-3 col-sm-6 col-12 mb-4">
                        <div className="text-center">
                            <img src="/img/allevent2.jpg" alt="" className="rounded img-fluid" width="250" height="270" />
                        </div>
                    </div>
                    <div className="col-lg-3 col-md-3 col-sm-6 col-12 mb-4">
                        <div className="text-center">
                            <img src="/img/allevent3.jpg" alt="" className="rounded img-fluid" width="250" height="270" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    );
}

export default Event;
