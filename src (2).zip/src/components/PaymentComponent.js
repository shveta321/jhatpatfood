import React from "react";

const PaymentComponent = () => {
  const loadRazorpay = (src) => {
    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = src;
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const handlePayment = async () => {
    const res = await loadRazorpay("https://checkout.razorpay.com/v1/checkout.js");

    if (!res) {
      alert("Razorpay SDK failed to load");
      return;
    }

    // Step 1: Create order from backend
    const orderRes = await fetch("http://localhost:5000/create-order", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ amount: 200 }) // Rs. 200
    });

    const orderData = await orderRes.json();

    // Step 2: Open Razorpay modal
    const options = {
      key: "your_key_id_here", // Public key
      amount: orderData.amount,
      currency: orderData.currency,
      name: "My Cloud Kitchen",
      description: "Food Order Payment",
      order_id: orderData.id,
      handler: function (response) {
        alert("Payment successful! ✅ Payment ID: " + response.razorpay_payment_id);
      },
      prefill: {
        name: "Sakshi",
        email: "sakshi@example.com",
        contact: "9999999999"
      },
      theme: {
        color: "#3399cc"
      }
    };

    const rzp = new window.Razorpay(options);
    rzp.open();
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h2>Pay ₹200 for Your Order</h2>
      <button onClick={handlePayment}>Pay with Razorpay</button>
    </div>
  );
};

export default PaymentComponent;
