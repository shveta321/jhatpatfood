import React, { useState } from "react";
import "./Lunch.css"; // You can style this as you want

const Lunch = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState("");

  const handleOrderClick = (item) => {
    setSelectedItem(item);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const name = e.target.name.value;
    const quantity = e.target.quantity.value;
    const deliveryMethod = e.target.deliveryMethod.value;

    alert(`Order placed:\nItem: ${selectedItem}\nName: ${name}\nQty: ${quantity}\nDelivery: ${deliveryMethod}`);
    setIsModalOpen(false);
  };

  return (
    <>
      <h1>Lunch Menu</h1>

      <div className="menu-container">
        {["Paneer Butter Masala", "Rajma Chawal", "Dal Makhani", "Veg Biryani"].map((item, index) => (
          <div className="menu-item" key={index}>
            <h3>{item}</h3>
            <p>Tasty and satisfying Indian lunch dish.</p>
            <button onClick={() => handleOrderClick(item)}>Order Now</button>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={closeModal}>
              &times;
            </span>
            <h2>Order: {selectedItem}</h2>
            <form onSubmit={handleSubmit}>
              <label>Name:</label>
              <input type="text" name="name" required />

              <label>Quantity:</label>
              <input type="number" name="quantity" min="1" required />

              <label>Delivery Method:</label>
              <select name="deliveryMethod" required>
                <option value="">--Select--</option>
                <option value="Pickup">Pickup</option>
                <option value="Home Delivery">Home Delivery</option>
              </select>

              <button type="submit">Submit Order</button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default Lunch;
