import React from "react";
import { useParams } from "react-router-dom";

const Order = () => {
  const { item } = useParams();

  return (
    <div>
      <h2>Order: {item}</h2>
      <form>
        <label>Name:</label>
        <input type="text" required />

        <label>Quantity:</label>
        <input type="number" min="1" required />

        <label>Delivery Method:</label>
        <select required>
          <option value="pickup">Pickup</option>
          <option value="home">Home Delivery</option>
        </select>

        <button type="submit">Submit Order</button>
      </form>
    </div>
  );
};

export default Order;
