import React, { useState } from "react";
import "./Lunch.css"; // Same CSS use kar sakti ho

const Breakfast = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState("");
  const [formData, setFormData] = useState({});
  const [showAddress, setShowAddress] = useState(false);
  const [finalPrice, setFinalPrice] = useState(0);

  const handleOrderClick = (item) => {
    setSelectedItem(item);
    setIsModalOpen(true);
    setFinalPrice(100); // Default price (change as needed)
  };
  const closeModal = () => {
    setIsModalOpen(false);
    setFormData({});
    setShowAddress(false);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    const updatedData = { ...formData, [name]: value };

    if (name === "deliveryMethod") {
      setShowAddress(value === "Home Delivery");
    }

    if (name === "quantity") {
      const qty = parseInt(value, 10) || 1;
      setFinalPrice(qty * 100); // Price logic
    }
    setFormData(updatedData);
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Order placed successfully!\n\nItem: ${selectedItem}\nName: ${formData.name}\nPhone: ${formData.phone}\nQty: ${formData.quantity}\nDelivery: ${formData.deliveryMethod}\nPayment: ${formData.paymentMethod}`);
    closeModal();
  };
  return (
    <>
      <h1>Breakfast Menu</h1>
      <div className="menu-container">
        {["Aloo Paratha", "Poha", "Idli Sambhar", "Upma", "Chole Bhature"].map((item, index) => (
          <div className="menu-item" key={index}>
            <h3>{item}</h3>
            <p>Delicious morning meal to start your day!</p>
            <button onClick={() => handleOrderClick(item)}>Order Now</button>
          </div>
        ))}
      </div>
      {isModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={closeModal}>&times;</span>

            <h3>Order: {selectedItem}</h3>
            <form onSubmit={handleSubmit}>
              {/* Name */}
              <div>
                <label>Name:</label>
                <input type="text" name="name" required onChange={handleChange} />

                {/* Phone */}
                <label>Phone:</label>
                <input type="tel" name="phone" required pattern="[0-9]{10}" onChange={handleChange} />
              </div>
              <div className="quan-deli">
                {/* Quantity */}
                <div className="form-group">
                  <label>Quantity:</label>
                  <input
                    type="number"
                    name="quantity"
                    min="1"
                    required
                    onChange={handleChange}
                  />
                </div>
                {/* Delivery Method */}
                <div className="form-group">
                  <label>Delivery Method:</label>
                  <select
                    name="deliveryMethod"
                    required
                    onChange={handleChange}
                  >
                    <option value="">--Select--</option>
                    <option value="Pickup">Pickup</option>
                    <option value="Home Delivery">Home Delivery</option>
                  </select>
                </div>
              </div>
              {/* Address if Home Delivery */}
              {showAddress && (
                <>
                  <div className="hous-numb">
                    <div className="form-group">
                      <label>House Number:</label>
                      <input
                        type="text"
                        name="houseNumber"
                        required
                        onChange={handleChange}
                        value={formData.houseNumber}
                      />
                    </div>
                    <div className="form-group">
                      <label>Street/Gali:</label>
                      <input
                        type="text"
                        name="street"
                        required
                        onChange={handleChange}
                        value={formData.street}
                      />
                    </div>
                  </div>
                  <div className="pin-cit">
                    <div className="form-group">
                      <label>Pincode:</label>
                      <input
                        type="text"
                        name="pincode"
                        required
                        pattern="[0-9]{6}"
                        onChange={handleChange}
                        value={formData.pincode}
                      />
                    </div>
                    <div className="form-group">
                      <label>City:</label>
                      <input
                        type="text"
                        name="city"
                        required
                        onChange={handleChange}
                        value={formData.city}
                      />
                    </div>
                  </div>
                  <label>Location:</label>
                  <input type="text" name="location" required onChange={handleChange} value={formData.location} />
                </>
              )}
              <div className="pay-coup">
                <div className="form-group">
                  <label>Payment Method:</label>
                  <select
                    name="paymentMethod"
                    required
                    onChange={handleChange}
                    value={formData.paymentMethod}
                  >
                    <option value="">--Select--</option>
                    <option value="Cash on Delivery">Cash on Delivery</option>
                    <option value="UPI">UPI</option>
                    <option value="Card">Card</option>
                  </select>
                </div>

                <div className="form-group">
                  <label>Coupon Code:</label>
                  <input
                    type="text"
                    name="couponCode"
                    onChange={handleChange}
                    placeholder="e.g. SAVE10"
                    value={formData.couponCode}
                  />
                </div>
              </div>

              <h5>Total Price: ₹{finalPrice}</h5>

              <button type="submit">Place Order</button>

            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default Breakfast;
