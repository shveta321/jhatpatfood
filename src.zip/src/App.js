import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import Header from './components/Header';
import Apfooter from './components/Apfooter';
import Homes from './components/Homes';
import Abouts from './components/Abouts';
import User from './components/User';
import Services from './components/Services';
import Event from './components/Event';
import BookUs from './components/BookUs';
import ChefTeam from './components/ChefTeam';
import Menus from './components/Menus';
import Breakfast from './pages/Breakfast';
import Order from './pages/Order';
import Lunch from "./pages/Lunch";
import Contact from './components/Contact';
import DailyMenu from './components/DailyMenu';
import Uploadmenu from "./components/Dashboard/Uploadmenu";
import Dash_home from './components/Dashboard/Dash_home';
import Login from "./components/Login";
import ProtectedRoute from "./components/ProtectedRoute";
// import Breakfast from "./Breakfast"; // Adjust path as needed



function App() {
  return (
    <Router>
      <Header />

      <Routes>
        {/* Route for the home page */}
        <Route path="/" element={<Homes />} />
        {/* Additional routes for other pages */}
        <Route path="/about" element={<Abouts />} />
        <Route path="/user" element={<User />} />
        <Route path="/service" element={<Services />} />
        <Route path="/event" element={<Event />} />
        <Route path="/bookus" element={<BookUs />} />
        <Route path="/chefteam" element={<ChefTeam />} />
        <Route path="/menus" element={<Menus />} />
        {/* Routes for the menu items */}
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login />} />
        <Route path="/menu/breakfast" element={<Breakfast />} />
        <Route path="/order/:item" element={<Order />} />
        <Route path="/menu/lunch" element={<Lunch />} />
        {/* Route for the daily menu */}
        <Route path="/dashboard/upload" element={<Uploadmenu />} />
        <Route path="/todaymenu" element={<DailyMenu />} />
        <Route path='/dashHome' element={<Dash_home />} />
        {/* <Route path="/Routes/breakfas" element={<Breakfas />} /> */}
<Route path="/dashboard/breakfast" element={<Breakfast />} />


        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dash_home />
            </ProtectedRoute>

          }
        />
        
      </Routes>
      <Abouts />
      <User />
      <Services />
      <Event />
      <Menus />
      <ChefTeam />
      <BookUs />
      {/* <Login/> */}
      <Apfooter />

    </Router>
  );
}

export default App;
