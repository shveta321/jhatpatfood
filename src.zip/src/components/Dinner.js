// src/components/Dinner.js
import React from 'react';

const Dinner = () => {
  return (
    <div>
      <h1>Dinner Menu</h1>

      <div className="menu-item">
        <h3>Shahi Paneer with Tandoori Roti</h3>
        <p>Creamy and royal paneer curry served with crispy tandoori rotis.</p>
      </div>

      <div className="menu-item">
        <h3>Chicken Curry with Rice</h3>
        <p>Spicy Indian chicken curry served with steamed basmati rice.</p>
      </div>

      <div className="menu-item">
        <h3>Mixed Vegetable Curry</h3>
        <p>Seasonal vegetables cooked in traditional spices, perfect with paratha or rice.</p>
      </div>

      <div className="menu-item">
        <h3>Rasgulla (Dessert)</h3>
        <p>Soft, spongy sweet balls soaked in sugar syrup to finish your dinner.</p>
      </div>
    </div>
  );
};

export default Dinner;
