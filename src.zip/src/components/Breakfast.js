// import React, { useState } from "react";

// const Breakfast = () => {
//   const [isModalOpen, setIsModalOpen] = useState(false);
//   const [selectedItem, setSelectedItem] = useState('');

//   const handleOrderClick = (item) => {
//     setSelectedItem(item);
//     setIsModalOpen(true);
//   };

//   const closeModal = () => {
//     setIsModalOpen(false);
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
  
//     console.log("Form Submitted", selectedItem);
//     closeModal();
//   };

//   return (
//     <>
//       <h1>Breakfast Menu</h1>

//       <div className="menu-container">
//         <div className="menu-item">
//           <h3>Poha</h3>
//           <p>Light and fluffy rice flakes tempered with mustard, curry leaves, and peanuts.</p>
//           <button className="order-button" onClick={() => handleOrderClick("Poha")}>Order Now</button>
//         </div>

//         <div className="menu-item">
//           <h3>Aloo Paratha</h3>
//           <p>Whole wheat flatbread stuffed with spicy mashed potatoes, served with curd & pickle.</p>
//           <button className="order-button" onClick={() => handleOrderClick("Aloo Paratha")}>Order Now</button>
//         </div>

//         <div className="menu-item">
//           <h3>Idli Sambhar</h3>
//           <p>Soft rice cakes served with lentil soup and coconut chutney.</p>
//           <button className="order-button" onClick={() => handleOrderClick("Idli Sambhar")}>Order Now</button>
//         </div>

//         <div className="menu-item">
//           <h3>Masala Dosa</h3>
//           <p>Crispy dosa filled with spiced potato filling, served with sambhar and chutney.</p>
//           <button className="order-button" onClick={() => handleOrderClick("Masala Dosa")}>Order Now</button>
//         </div>
//       </div>

//       {/* Modal (Form) */}
//       {isModalOpen && (
//         <div id="myModal" className="modal">
//           <div className="modal-content">
//             <span className="close" onClick={closeModal}>&times;</span>
//             <form id="breakfastOrderForm" onSubmit={handleSubmit}>
//               {/* Hidden item */}
//               <input type="hidden" id="menuItem" name="menuItem" value={selectedItem} />

//               {/* Name */}
//               <label htmlFor="name">Name:</label>
//               <input type="text" id="name" name="name" required /><br /><br />

//               {/* Email */}
//               <label htmlFor="email">Email:</label>
//               <input type="email" id="email" name="email" required /><br /><br />

//               {/* Contact Number */}
//               <label htmlFor="phone">Contact Number:</label>
//               <input type="tel" id="phone" name="phone" required /><br /><br />

//               {/* Quantity */}
//               <label htmlFor="quantity">Quantity:</label>
//               <input type="number" id="quantity" name="quantity" min="1" required /><br /><br />

//               {/* Delivery/Pickup */}
//               <label htmlFor="deliveryMethod">Delivery Method:</label>
//               <select id="deliveryMethod" name="deliveryMethod" required>
//                 <option value="">--Select--</option>
//                 <option value="Pickup">Pickup</option>
//                 <option value="Home Delivery">Home Delivery</option>
//               </select><br /><br />

//               {/* Preferred Date */}
//               <label htmlFor="date">Preferred Date:</label>
//               <input type="date" id="date" name="date" required /><br /><br />

//               {/* Special Instructions */}
//               <label htmlFor="message">Special Instructions:</label>
//               <textarea id="message" name="message"></textarea><br /><br />

//               {/* Submit Button */}
//               <input type="submit" value="Submit Order" />
//             </form>
//           </div>
//         </div>
//       )}
//     </>
//   );
// }

// export default Breakfast;
