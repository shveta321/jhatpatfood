import React, { useEffect, useState } from "react";
import axios from "axios";
import "./PohaManagement.css"; // Optional: for styling

const PohaManagement = () => {
  const [pohaData, setPohaData] = useState([]);
  const [editData, setEditData] = useState(null);

  useEffect(() => {
    fetchPoha();
  }, []);

  const fetchPoha = async () => {
    const res = await axios.get("http://localhost:5000/poha");
    setPohaData(res.data);
  };

  const handleDelete = async (id) => {
    await axios.delete(`http://localhost:5000/poha/${id}`);
    fetchPoha();
  };

  const handleUpdate = async () => {
    await axios.put(`http://localhost:5000/poha/${editData.id}`, editData);
    setEditData(null);
    fetchPoha();
  };

  return (
    <div className="table-wrapper">
      <h2>Poha Management</h2>

      <table>
        <thead>
          <tr>
            <th>Image</th>
            <th>Item</th>
            <th>Price</th>
            <th>Date</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {pohaData.map((item) => (
            <tr key={item.id}>
              <td><img src={item.image} alt={item.name} width="60" /></td>
              <td>{item.name}</td>
              <td>₹{item.price}</td>
              <td>{new Date(item.date).toLocaleDateString()}</td>
              <td>{item.status}</td>
              <td>
                <button onClick={() => setEditData(item)}>Edit</button>
                <button onClick={() => handleDelete(item.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {editData && (
        <div className="edit-form">
          <h3>Update Item</h3>
          <input
            type="text"
            value={editData.name}
            onChange={(e) => setEditData({ ...editData, name: e.target.value })}
          />
          <input
            type="number"
            value={editData.price}
            onChange={(e) => setEditData({ ...editData, price: e.target.value })}
          />
          <select
            value={editData.status}
            onChange={(e) => setEditData({ ...editData, status: e.target.value })}
          >
            <option value="Available">Available</option>
            <option value="Unavailable">Unavailable</option>
          </select>
          <button onClick={handleUpdate}>Save</button>
        </div>
      )}
    </div>
  );
};

export default PohaManagement;
