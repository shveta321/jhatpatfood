import React, { useEffect, useState } from "react";

const UploadBreakfast = () => {
  const [items, setItems] = useState([]);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [type, setType] = useState("breakfast");
  const [photo, setPhoto] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const fetchItems = async () => {
    const res = await fetch("http://localhost:5000/items");
    const data = await res.json();
    setItems(data);
  };

  useEffect(() => {
    fetchItems();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name || !type) return alert("Name and Type are required");

    const formData = new FormData();
    formData.append("name", name);
    formData.append("description", description);
    formData.append("price", price);
    formData.append("type", type);
    if (photo) formData.append("photo", photo);

    const url = editingId
      ? `http://localhost:5000/items/${editingId}`
      : "http://localhost:5000/upload-item";

    const method = editingId ? "PUT" : "POST";

    const res = await fetch(url, {
      method,
      body: formData,
    });

    const data = await res.json();
    alert(data.message);
    setName("");
    setDescription("");
    setPrice("");
    setType("breakfast");
    setPhoto(null);
    setShowModal(false);
    setEditingId(null);
    fetchItems();
  };

  const handleDelete = async (id) => {
    if (window.confirm("Delete this item?")) {
      const res = await fetch(`http://localhost:5000/items/${id}`, {
        method: "DELETE",
      });
      const data = await res.json();
      alert(data.message);
      fetchItems();
    }
  };

  const handleEdit = (item) => {
    setName(item.name);
    setDescription(item.description);
    setPrice(item.price);
    setType(item.type);
    setEditingId(item.id);
    setPhoto(null);
    setShowModal(true);
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1 style={{ textAlign: "center", color: "olivedrab" }}>
        Upload Menu Item
      </h1>

      <button onClick={() => setShowModal(true)}>+ Upload Item</button>

      {showModal && (
        <div style={{
          position: "fixed", top: "18%", left: "50%", transform: "translateX(-50%)",
          backgroundColor: "#fff", padding: "20px", border: "1px solid #ccc", zIndex: 1000,
          borderRadius: "8px", boxShadow: "0 4px 12px rgba(0,0,0,0.2)"
        }}>
          <h3>{editingId ? "Edit" : "Upload"} Item</h3>
          <form onSubmit={handleSubmit}>
            <input type="text" placeholder="Item Name" value={name} onChange={e => setName(e.target.value)} required />
            <input type="file" accept="image/*" onChange={e => setPhoto(e.target.files[0])} />
            <input type="text" placeholder="Description" value={description} onChange={e => setDescription(e.target.value)} />
            <input type="number" step="0.01" placeholder="Price" value={price} onChange={e => setPrice(e.target.value)} />

            <select value={type} onChange={e => setType(e.target.value)} required>
              <option value="">Select Menu Type</option>
              <option value="breakfast">Breakfast</option>
              <option value="lunch">Lunch</option>
              <option value="fast food">Fast Food</option>
              <option value="others">Others</option>
            </select>

            <button type="submit">{editingId ? "Update" : "Submit"}</button>
            <button type="button" onClick={() => { setShowModal(false); setEditingId(null); }}>Cancel</button>
          </form>
        </div>
      )}

      <table className="table table-striped table-bordered" border="1" cellPadding="8" style={{ width: "100%", marginTop: "20px" }}>
        <thead>
          <tr>
            <th>ID</th>
            <th>Photo</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Type</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {items.map(item => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td><img src={`http://localhost:5000/uploads/${item.photo}`} alt={item.name} width="60" /></td>
              <td>{item.name}</td>
              <td>{item.description}</td>
              <td>₹{item.price}</td>
              <td>{item.type}</td>
              <td>
                <button onClick={() => handleEdit(item)}>✏️ Edit</button>
                <button onClick={() => handleDelete(item.id)}>🗑️ Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UploadBreakfast;
