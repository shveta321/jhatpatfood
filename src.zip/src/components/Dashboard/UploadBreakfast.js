import React, { useState, useEffect } from "react";

const UploadBreakfast = () => {
  const [name, setName] = useState("");
  const [photo, setPhoto] = useState(null);
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [items, setItems] = useState([]);
  const [showModal, setShowModal] = useState(false);

  // Fetch items from backend
  const fetchItems = async () => {
    try {
      const res = await fetch("http://localhost:5000/breakfast-items");
      const data = await res.json();
      setItems(data);
    } catch (err) {
      console.error("Failed to fetch breakfast items", err);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name || !photo) return alert("Name and photo required");

    const formData = new FormData();
    formData.append("name", name);
    formData.append("photo", photo);
    formData.append("description", description);
    formData.append("price", price);

    try {
      const res = await fetch("http://localhost:5000/upload-breakfast", {
        method: "POST",
        body: formData,
      });

      const data = await res.json();

      if (res.ok) {
        alert("✅ Item uploaded successfully");
        setName("");
        setPhoto(null);
        setDescription("");
        setPrice("");
        setShowModal(false);
        fetchItems();
      } else {
        alert("❌ Upload failed: " + (data.error || "Unknown error"));
      }
    } catch (err) {
      console.error("❌ Error:", err);
      alert("❌ Upload failed due to network/server error");
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Breakfast Menu</h2>

      {/* Upload Button */}
      <button onClick={() => setShowModal(true)}>Upload Breakfast Item</button>

      {/* Modal Dialog */}
      {showModal && (
        <div
          style={{
            position: "fixed",
            top: "10%",
            left: "50%",
            transform: "translateX(-50%)",
            backgroundColor: "#fff",
            padding: "20px",
            border: "1px solid #ccc",
            zIndex: 1000,
            borderRadius: "8px",
            boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
          }}
        >
          <h3>Upload New Item</h3>
          <form onSubmit={handleSubmit} encType="multipart/form-data">
            <input
              type="text"
              placeholder="Item Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
            <input
              type="file"
              accept="image/*"
              onChange={(e) => setPhoto(e.target.files[0])}
              required
            />
            <input
              type="text"
              placeholder="Description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
            <input
              type="number"
              step="0.01"
              placeholder="Price (e.g. 50)"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
            />
            <button type="submit">Submit</button>
            <button type="button" onClick={() => setShowModal(false)}>
              Cancel
            </button>
          </form>
        </div>
      )}

      {/* Table */}
      <h3>Uploaded Items</h3>
      <table border="1" cellPadding="8" style={{ width: "100%", marginTop: "20px" }}>
        <thead>
          <tr>
            <th>ID</th>
            <th>Photo</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price (₹)</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td>
                <img
                  src={`http://localhost:5000/uploads/${item.photo}`}
                  alt={item.name}
                  width="60"
                />
              </td>
              <td>{item.name}</td>
              <td>{item.description}</td>
              <td>{item.price}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UploadBreakfast;
