import { useState, useCallback } from "react";
import React from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import Header from "../Header";
// import Navbar from "../components/navbar/Navbar";
// import  Sidebar from "../components/sidebar/Sidebar";

const Dash_Route = () => {
  const [openSidebarToggle, setOpenSidebarToggle] = useState(false);
 
  const toggleSidebar = useCallback(() => {
    setOpenSidebarToggle((prev) => !prev);
  }, []);

  return (
    <div className="layout">
      < Sidebar openSidebarToggle={openSidebarToggle} OpenSidebar={toggleSidebar} />

      <div className="mainContent">
        <Header OpenSidebar={toggleSidebar} />
        <div className="outlet">
          <Outlet />
        </div>
      </div>
    </div>
  );
};
export default React.memo(Dash_Route);
