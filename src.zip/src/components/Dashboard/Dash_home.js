import React from "react";
import Sidebar from "./Sidebar";

const Dash_home = () => {
  return (
    <div style={{ display: "flex" }}>
      <Sidebar />
      <div style={{ marginLeft: "220px", padding: "20px" }}>
        <h1>Welcome to Admin Dashboard</h1>
        <p>Use sidebar to navigate.</p>
      </div>
    </div>
    
  );
};

export default Dash_home;
