// Sidebar.js
import React from "react";
import { Link } from "react-router-dom";

const Sidebar = () => {
  return (
    <div style={{
      width: "200px",
      background: "#333",
      color: "#fff",
      height: "100vh",
      padding: "20px"
    }}>
      <h2>Dashboard</h2>
      <ul style={{ listStyle: "none", padding: 0 }}>
        <li style={{ padding: "16px 0px 4px 4px" }}>
          <Link to="/dashboard" style={{ color: "white", textDecoration: "none", fontWeight: "bold" }}>
            Home
          </Link>
        </li>
        <li style={{ padding: "16px 0px 4px 4px" }}>
          <Link to="/dashboard/upload" style={{ color: "white", textDecoration: "none", fontWeight: "bold" }}>
            Upload Menu
          </Link>
        </li>
        <li style={{ padding: "16px 0px 4px 4px" }}>
          <Link to="/todaymenu" style={{ color: "white", textDecoration: "none", fontWeight: "bold" }}>
            View Today's Menu
          </Link>
        </li>
        <li style={{ padding: "16px 0px 4px 4px" }}>
          <Link to="/dashboard/breakfast" style={{ color: "white", textDecoration: "none", fontWeight: "bold" }}>
  Breakfast
</Link>

        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
