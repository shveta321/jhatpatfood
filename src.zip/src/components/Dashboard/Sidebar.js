import React from "react";
import { Link } from "react-router-dom";

const Sidebar = () => {
  return (
    <div style={{
      width: "200px",
      background: "#333",
      color: "#fff",
      height: "100vh",
      padding: "20px",
      position: "fixed",
    }}>
      <h2>Dashboard</h2>
      <ul style={{ listStyle: "none", padding: 0 }}>
        <li><Link to="/dashboard" style={{ color: "#fff" }}>Home</Link></li>
        <li><Link to="/dashboard/upload" style={{ color: "#fff" }}>Upload Menu</Link></li>
        <li><Link to="/todaymenu" style={{ color: "#fff" }}>View Today's Menu</Link></li>
      </ul>
    </div>
  );
};

export default Sidebar;
