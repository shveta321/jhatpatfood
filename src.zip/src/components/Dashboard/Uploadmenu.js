import React from "react";
import PhotoUploader from "./PhotoUploader"; // agar same folder me hai

const Uploadmenu = () => {
  return (
    // <div  className="updmenu" style={{ display: "flex" }}>
    
      <div style={{ marginLeft: "220px", padding: "20px" }}>
        <PhotoUploader />
      </div>
    // </div>
  );
};

export default Uploadmenu;
