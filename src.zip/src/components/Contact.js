import React, { useState } from "react";
import "./Contact.css";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",            // ✅ Updated from Name to name
    email: "",
    phone: "",
    country: "",
    postalCode: "",
    inquiry: "",
  });

  const [responseMsg, setResponseMsg] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch("http://localhost:3000/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (res.ok) {
        setResponseMsg("Form submitted successfully!");
        setFormData({
          name: "",
          email: "",
          phone: "",
          country: "",
          postalCode: "",
          inquiry: "",
        });
      } else {
        setResponseMsg(data.message || "Something went wrong!");
      }
    } catch (err) {
      setResponseMsg("Server error, please try again later.");
    }
  };

  return (
    <div className="contact-container">
      <h2>Do You Own A Restaurant Or Food Business?</h2>
      <form className="contact-form" onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Full Name *"
          value={formData.name}
          onChange={handleChange}
          required
        />
        <input
          type="email"
          name="email"
          placeholder="example@example.com *"
          value={formData.email}
          onChange={handleChange}
          required
        />
        <input
          type="tel"
          name="phone"
          placeholder="Phone Number *"
          value={formData.phone}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="country"
          placeholder="Country"
          value={formData.country}
          onChange={handleChange}
        />
        <input
          type="text"
          name="postalCode"
          placeholder="Postal Code"
          value={formData.postalCode}
          onChange={handleChange}
        />
        <textarea
          name="inquiry"
          rows="5"
          placeholder="Write your comment or query here..."
          value={formData.inquiry}
          onChange={handleChange}
          required
        ></textarea>

        <button type="submit">Submit</button>
        {responseMsg && <p className="response-message">{responseMsg}</p>}
      </form>
    </div>
  );
};

export default Contact;
