import React from 'react';
// import { Link } from 'react-router-dom';
import { Route } from 'react-router-dom';




function Services() {
    return (
        <section>
        <div className="container-fluid">
            <div className="container mb-4 mt-4">
                <div className="wel-jhatp-1">
                    <small className="wel-jhat-1">Our Services</small>
                </div>
                <p className="offe">What We Offer</p>
                <div className="row">
                    <div className="col-md-3">
                        <div className="card-font-1 mb-3">
                            <i className="fa-solid fa-cheese  fa-4x text-"></i>
                            <h4 className="mb-3">Wedding Services</h4>
                            <p className="mb-4">Contrary to popular belief, ipsum is not simply random.</p>
                            <a href="#" className="btn btn-primary px-4 py-2 rounded-pill">Read More</a>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="card-font-2 mb-3">
                            <i className="fa-solid fa-pizza-slice  fa-4x"></i>
                            <h4 className="mb-3">Corporate Catering</h4>
                            <p className="mb-4">Contrary to popular belief, ipsum is not simply random.</p>
                            <a href="#" className="btn btn-primary px-4 py-2 rounded-pill">Read More</a>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="card-font-3 mb-3">
                            <i className="fa-solid fa-hotdog  fa-4x"></i>
                            <h4 className="mb-3">
                                Cocktail Reception</h4>
                            <p className="mb-4">Contrary to popular belief, ipsum is not simply random.</p>
                            <a href="#" className="btn btn-primary px-4 py-2 rounded-pill">Read More</a>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="card-font-4 mb-3">
                            <i className="fas fa-hamburger  fa-4x"></i>
                            <h4 className="mb-3">Bento Catering</h4>
                            <p className="mb-4">Contrary to popular belief, ipsum is not simply random.</p>
                            <a href="#" className="btn px-4 py-2 rounded-pill">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    );
}

export default Services;
