import React from 'react';
// import { Link } from 'react-router-dom';
import { Route } from 'react-router-dom';




function ChefTeam() {
    return (
        <section>
            <div className="container-fluid mt-5">
                <div className="container">
                    <div className="wel-jhatp-2">
                        <span className="wel-jhat-2">Our Menu</span>
                        <h1>We have experienced chef Team</h1>
                    </div>
                    <div className="row mt-5">
                        <div className="col-lg-3 col-md-3 col-sm-6 col-12 mb-4">
                            <div className="text-center-1">
                                <img src="img/chef.jpg" alt="Decoration Chef" className="img-chef" width="250" height="270" />
                                <h4 style={{ color: 'white' }}>Decoration Chef</h4>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-3 col-sm-6 col-12 mb-4">
                            <div className="text-center-1">
                                <img src="img/chef2.jpg" alt="Executive Chef" className="img-chef" width="250" height="270" />
                                <h4 style={{ color: 'white' }}>Executive Chef</h4>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-3 col-sm-6 col-12 mb-4">
                            <div className="text-center-1">
                                <img src="img/chef3.jpg" alt="Kitchen Porter" className="img-chef" width="250" height="270" />
                                <h4 style={{ color: 'white' }}>Kitchen Porter</h4>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-3 col-sm-6 col-12 mb-4">
                            <div className="text-center-1">
                                <img src="img/chef4.jpg" alt="Head Chef" className="img-chef" width="250" height="270" />
                                <h4 style={{ color: 'white' }}>Head Chef</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}



export default ChefTeam;