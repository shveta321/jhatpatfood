import React from 'react';
// import { Link } from 'react-router-dom';
import { Route } from 'react-router-dom';


function Menus() {
    return (
        <section>
            <div className="chart-sect">
                <div className="container">
                    <div className="wel-jhatp-2">
                        <span className="wel-jhat-2">Our Menu</span>
                    </div>
                    <p className="offe">Most Popular Food in the World</p>

                    {/* Menu Categories */}
                    <div className="all-event">
                        <div className="wel-jhatp-2 mb-3">
                            <a className="d-flex py-2 mx-2 active" data-bs-toggle="pill" href="#tab-6">
                                <span className="wel-jhat-3">Starter</span>
                            </a>
                        </div>
                        <div className="wel-jhatp-2 mb-3">
                            <a className="d-flex py-2 mx-2" data-bs-toggle="pill" href="#tab-7">
                                <span className="wel-jhat-3">Main Course</span>
                            </a>
                        </div>
                        <div className="wel-jhatp-2 mb-3">
                            <a className="d-flex py-2 mx-2" data-bs-toggle="pill" href="#tab-8">
                                <span className="wel-jhat-3">Drinks</span>
                            </a>
                        </div>
                        <div className="wel-jhatp-2 mb-3">
                            <a className="d-flex py-2 mx-2" data-bs-toggle="pill" href="#tab-9">
                                <span className="wel-jhat-3">Our Special</span>
                            </a>
                        </div>
                    </div>

                    {/* Food Items */}
                    <div>
                        {/* Row 1 */}
                        <div className="row">
                            <div className="col-sm-6 mb-3">
                                <div className="chart-thali">
                                    <img src="/img/thali1.jpg" alt="Paneer" width="120" height="100" className="rounded-circle" />
                                    <div>
                                        <div className="chart-th">
                                            <h4>Paneer</h4>
                                            <h4 style={{ color: "rgb(216, 155, 75)" }}>$90</h4>
                                        </div>
                                        <div>
                                            Consectetur adipiscing elit sed dwso eiusmod tempor incididunt ut labore.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-sm-6 mb-3">
                                <div className="chart-thali">
                                    <img src="/img/Sabudana Tikki.jpg" alt="Sabudana Tikki" width="120" height="100" className="rounded-circle" />
                                    <div>
                                        <div className="chart-th">
                                            <h4>Sabudana Tikki</h4>
                                            <h4 style={{ color: "rgb(216, 155, 75)" }}>$90</h4>
                                        </div>
                                        <div>
                                            Consectetur adipiscing elit sed dwso eiusmod tempor incididunt ut labore.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Row 2 */}
                        <div className="row">
                            <div className="col-sm-6 mb-3">
                                <div className="chart-thali">
                                    <img src="/img/Paneer.jpg" alt="Dhosa" width="120" height="100" className="rounded-circle" />
                                    <div>
                                        <div className="chart-th">
                                            <h4>Dhosa</h4>
                                            <h4 style={{ color: "rgb(216, 155, 75)" }}>$90</h4>
                                        </div>
                                        <div>
                                            Consectetur adipiscing elit sed dwso eiusmod tempor incididunt ut labore.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-sm-6 mb-3">
                                <div className="chart-thali">
                                    <img src="/img/Bacon.jpg" alt="Bacon" width="120" height="100" className="rounded-circle" />
                                    <div>
                                        <div className="chart-th">
                                            <h4>Bacon</h4>
                                            <h4 style={{ color: "rgb(216, 155, 75)" }}>$90</h4>
                                        </div>
                                        <div>
                                            Consectetur adipiscing elit sed dwso eiusmod tempor incididunt ut labore.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Row 3 */}
                        <div className="row">
                            <div className="col-sm-6 mb-3">
                                <div className="chart-thali">
                                    <img src="/img/thali5.jpg" alt="Thali" width="120" height="100" className="rounded-circle" />
                                    <div>
                                        <div className="chart-th">
                                            <h4>Thali</h4>
                                            <h4 style={{ color: "rgb(216, 155, 75)" }}>$90</h4>
                                        </div>
                                        <div>
                                            Consectetur adipiscing elit sed dwso eiusmod tempor incididunt ut labore.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-sm-6 mb-3">
                                <div className="chart-thali">
                                    <img src="/img/Blooming.jpg" alt="Blooming" width="120" height="100" className="rounded-circle" />
                                    <div>
                                        <div className="chart-th">
                                            <h4>Blooming</h4>
                                            <h4 style={{ color: "rgb(216, 155, 75)" }}>$90</h4>
                                        </div>
                                        <div>
                                            Consectetur adipiscing elit sed dwso eiusmod tempor incididunt ut labore.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
    );
}

export default Menus;
