import React from 'react';
// import { Link } from 'react-router-dom';
import { Route } from 'react-router-dom';




function BookUs() {
    return (
        <section className="container-fluid">
            <div className="container">
                <div className="saled-1">
                    <div className="form-container">
                        <h1 style={{ textAlign: 'center' }}>Book Us</h1>
                        <form method="POST">
                            <div className="saled-log">
                                <div>
                                    <label htmlFor="country">Select Country</label>
                                    <select id="country" name="country" required>
                                        <option value="">--Choose Country--</option>
                                        <option value="India">India</option>
                                        <option value="USA">USA</option>
                                        <option value="UK">UK</option>
                                    </select>
                                </div>
                                <div>
                                    <label htmlFor="city">Select City</label>
                                    <input type="text" id="city" name="city" placeholder="Enter City" required />
                                </div>
                                <div>
                                    <label htmlFor="palace">Select Palace</label>
                                    <input type="text" id="palace" name="palace" placeholder="Enter Palace Name" required />
                                </div>
                            </div>

                            <div className="saled-log">
                                <div>
                                    <label htmlFor="eventType">Event Type</label>
                                    <select id="eventType" name="eventType" required>
                                        <option value="Small Event">Small Event</option>
                                        <option value="Big Event">Big Event</option>
                                    </select>
                                </div>
                                <div>
                                    <label htmlFor="noOfPalace">No. Of Palaces</label>
                                    <input type="number" id="noOfPalace" name="noOfPalace" placeholder="e.g., 1, 2, 3" required />
                                </div>
                                <div>
                                    <label htmlFor="foodType">Food Preference</label>
                                    <select id="foodType" name="foodType" required>
                                        <option value="Vegetarian">Vegetarian</option>
                                        <option value="Non-Vegetarian">Non-Vegetarian</option>
                                        <option value="Both">Both</option>
                                    </select>
                                </div>
                            </div>

                            <div className="saled-log">
                                <div>
                                    <label htmlFor="contact">Your Contact No.</label>
                                    <input type="tel" id="contact" name="contact" placeholder="e.g., 9876543210" required />
                                </div>
                                <div>
                                    <label htmlFor="date">Preferred Date</label>
                                    <input type="date" id="date" name="date" required />
                                </div>
                                <div>
                                    <label htmlFor="email">Enter Your Email</label>
                                    <input type="email" id="email" name="email" placeholder="example@mail.com" required />
                                </div>
                            </div>

                            <div className="sub-btn">
                                <button type="submit" className="sub">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default BookUs;