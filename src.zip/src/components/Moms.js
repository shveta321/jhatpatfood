import React from 'react';

function Moms() {
  return (
    <div>
      <h1>Momos Page</h1>
      <p>Delicious momos coming soon!</p>
    </div>
  );
}

export default Moms;
