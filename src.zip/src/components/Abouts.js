import React from 'react';
// import { Link } from 'react-router-dom';
import { Route } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShare } from '@fortawesome/free-solid-svg-icons';
import { faArrowRight } from '@fortawesome/free-solid-svg-icons';
// import { Link } from 'react-router-dom';


function Abouts() {
    return (
      
        <section className="features">
        <div className="container">
            <div className="feat-abo">
                <div className="feature">
                <img src="/img/secbn.jpg" alt="" width="450" height="400" className="sect-ban" />
                </div>
                <div className="feature-1">
                    <small
                        className="d-inline-block fw-bold text-dark text-uppercase bg-light border border-danger rounded-pill px-4 py-1 mb-3">About
                        Us</small>
                    <h1>Trusted By 200 + satisfied clients</h1>
                    <p className="text-abou">Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore eit
                        esdioilore magna
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullaemco laboeeiris nisi ut aliquip
                        ex ea commodo consequat. Duis aute irure dolor iesdein reprehendeerit in voluptate velit esse
                        cillum dolore.</p>
                    <div>
                        <div className="row g-4 text-dark mb-5">
                            <div className="col-sm-6">
                                <FontAwesomeIcon icon={faShare} className="me-2" />Fresh and food Delivery
                            </div>
                            <div className="col-sm-6">
                                 <FontAwesomeIcon icon={faShare} className="me-2" />24/7 Customer Support
                            </div>
                            <div className="col-sm-6">
                                 <FontAwesomeIcon icon={faShare} className="me-2" />Easy Customization Options
                            </div>
                            <div className="col-sm-6">
                                 <FontAwesomeIcon icon={faShare} className="me-2" />Delicious Deals for Delicious Meals
                            </div>
                        </div>
                        
                        <a href="" className="butn-abo py-3 px-5 ">About Us      <FontAwesomeIcon icon={faArrowRight} className="ps-2" />
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </section>
    );
}

export default Abouts;
