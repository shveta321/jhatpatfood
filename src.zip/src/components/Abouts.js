import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShare, faArrowRight } from '@fortawesome/free-solid-svg-icons';
import { motion } from 'framer-motion';

function Abouts() {
    return (
        <section className="features">
            <div className="container">
                <div className="feat-abo">

                    {/* ✅ Image Animation: Bottom to Top */}
                    <motion.div
                        className="feature"
                        initial={{ opacity: 0, y: 100 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 1 }}
                        viewport={{ once: true, amount: 0.5 }}
                    >
                        <img
                            src="/img/secbn.jpg"
                            alt=""
                            width="450"
                            height="400"
                            className="sect-ban"
                            style={{ borderRadius: '10px' }}
                        />
                    </motion.div>

                    {/* ✅ Text Animation: Bottom to Top (same as image) */}
                    <motion.div
                        className="feature-1"
                        initial={{ opacity: 0, y: 100 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 1.2 }}
                        viewport={{ once: true, amount: 0.5 }}
                    >
                        <small className="d-inline-block fw-bold text-dark text-uppercase bg-light border border-danger rounded-pill px-4 py-1 mb-3">
                            About Us
                        </small>
                        <h1>Trusted By 200+ Satisfied Clients</h1>
                        <p className="text-abou">
                            Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore eit
                            esdioilore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                            ullaemco laboeeiris nisi ut aliquip ex ea commodo consequat. Duis aute irure
                            dolor iesdein reprehendeerit in voluptate velit esse cillum dolore.
                        </p>
                        <div>
                            <div className="row g-4 text-dark mb-5">
                                <div className="col-sm-6">
                                    <FontAwesomeIcon icon={faShare} className="me-2" />Fresh and food Delivery
                                </div>
                                <div className="col-sm-6">
                                    <FontAwesomeIcon icon={faShare} className="me-2" />24/7 Customer Support
                                </div>
                                <div className="col-sm-6">
                                    <FontAwesomeIcon icon={faShare} className="me-2" />Easy Customization Options
                                </div>
                                <div className="col-sm-6">
                                    <FontAwesomeIcon icon={faShare} className="me-2" />Delicious Deals for Delicious Meals
                                </div>
                            </div>

                            <a href="#" className="butn-abo py-3 px-5">
                                About Us <FontAwesomeIcon icon={faArrowRight} className="ps-2" />
                            </a>
                        </div>
                    </motion.div>

                </div>
            </div>
        </section>
    );
}

export default Abouts;
