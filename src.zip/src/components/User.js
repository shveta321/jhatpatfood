import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUsers, faUsersCog, faCheck } from '@fortawesome/free-solid-svg-icons';
import { motion } from 'framer-motion';

function User() {
    return (
        <section>
            <div className="container mt-3">
                <div className="row">

                    {/* Left Cards with Bottom to Top Animation */}
                    <motion.div
                        className="col-lg-7 col-md-12 mt-5"
                        initial={{ opacity: 0, y: 100 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 1 }}
                        viewport={{ once: true, amount: 0.5 }}
                    >
                        <div className="row mt-3">
                            <div className="col-lg-4 col-md-4 col-sm-6 col-12 mt-3">
                                <div className="card-1 text-center p-3">
                                    <FontAwesomeIcon icon={faUsers} className="fa-4x mb-3 text-white" />
                                    <h1 className="display-6 fw-bold">689</h1>
                                    <p className="text-dark text-uppercase fw-bold mb-0">Happy Customers</p>
                                </div>
                            </div>
                            <div className="col-lg-4 col-md-4 col-sm-6 col-12 mt-3">
                                <div className="card-2 text-center p-3">
                                    <FontAwesomeIcon icon={faUsersCog} className="fa-4x mb-3 text-white" />
                                    <h1 className="display-6 fw-bold">107</h1>
                                    <p className="text-dark text-uppercase fw-bold mb-0">Expert Chefs</p>
                                </div>
                            </div>
                            <div className="col-lg-4 col-md-4 col-sm-6 col-12 mt-3">
                                <div className="card-3 text-center p-3">
                                    <FontAwesomeIcon icon={faCheck} className="fa-4x mb-3 text-white" />
                                    <h1 className="display-6 fw-bold">253</h1>
                                    <p className="text-dark text-uppercase fw-bold mb-0">Events Complete</p>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                    <motion.div
                        className="col-lg-5 col-md-12 mt-4 mb-4 text-center"
                        initial={{ opacity: 0, y: 100 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 1.2 }}
                        viewport={{ once: true, amount: 0.5 }}
                    >
                        <img
                            src="/img/sec3.jpg"
                            alt="Image"
                            className="img-fluid img-jha-1"
                            width="485"
                        />
                    </motion.div>
                </div>
            </div>
        </section>
    );
}

export default User;
