import React,{useState} from "react";
import { Link} from "react-router-dom";
import "./Dropdown.css";

const serviceDropdown = "My dropdown content";  
function Dropdown(){
    const [dropdown,setIsDropdown] = useState(false);

    return
    <>
    <ul className={dropdown ?"services-submenu clicked" : "services-submenu "} onClick={()=> setIsDropdown(!dropdown)}>
        { serviceDropdown.map(item =>
            {
                return<li key={item.id}>
                    <Link to={item.path} className="={item.cName}onClick={()=> setIsDropdown(!dropdown)}">{item.title}</Link>
                </li>
            }
        )
        
        }

    </ul>
    </>
}
export default Dropdown
