// src/components/Lunch.js
import React from 'react';

const Lunch = () => {
  return (
    <div>
      <h1>Lunch Menu</h1>

      <div className="menu-item">
        <h3>Paneer Butter Masala with Naan</h3>
        <p>Soft cottage cheese cubes in rich creamy tomato gravy served with butter naan.</p>
      </div>

      <div className="menu-item">
        <h3>Dal Tadka with Jeera Rice</h3>
        <p>Tempered yellow lentils served with aromatic cumin rice.</p>
      </div>

      <div className="menu-item">
        <h3>Chicken Biryani</h3>
        <p>Fragrant basmati rice cooked with marinated chicken and aromatic spices.</p>
      </div>

      <div className="menu-item">
        <h3>Veg Thali</h3>
        <p>Complete vegetarian platter with dal, sabzi, rice, roti, salad, and sweet.</p>
      </div>
    </div>
  );
};

export default Lunch;
