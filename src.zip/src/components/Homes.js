import React from 'react'
import { Link } from 'react-router-dom';
// import jhatp from '../assets/img/thali1.jpg';




function Homes() {
    return (
        <section className="hero-bann">
            <div className="jhat-bann">
                <div className="hero-text">
                <div className="today" style={{ marginTop: "20px" }}>
        <Link to="/todaymenu" style={{ 
          fontSize: "18px", 
          padding: "10px 20px",  
          color: "orange", 
          textDecoration: "none", 
          borderRadius: "8px" 
        }}>
          TODAY MENU
        </Link>
      </div>

                    <div className="wel-jhatp">
                        <small className="wel-jhat"> WELCOME TO JHATPAT</small>
                    </div>
                    <p className="food-jhat">
                        Jhatpat <span className="A-tif">Food & </span>Tiffin
                        <br />
                        Service <span className="clou-kic">(A cloud Kitchen)</span>
                    </p>
                    <div className="button-group">
                        <a href="#" className="btn-book">Book Now</a>
                        <a href="#" className="btn-know">Know More</a>
                    </div>
                </div>
                <div className="main-im">
                <img src="/img/jhatp1.png" width="500" height="500" alt="Jhatpat Image" />
                </div>
            </div>
        </section>
    );
}

export default Homes;
