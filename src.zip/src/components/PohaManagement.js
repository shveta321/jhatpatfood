import React, { useEffect, useState } from "react";
import axios from "axios";

const PohaManagement = () => {
  const [pohaData, setPohaData] = useState([]);
  const [editData, setEditData] = useState(null);

  useEffect(() => {
    fetchPoha();
  }, []);

  const fetchPoha = async () => {
    const res = await axios.get("http://localhost:5000/poha");
    setPohaData(res.data);
  };

  const handleDelete = async (id) => {
    await axios.delete(`http://localhost:5000/poha/${id}`);
    fetchPoha();
  };

  const handleUpdate = async () => {
    await axios.put(`http://localhost:5000/poha/${editData.id}`, editData);
    setEditData(null);
    fetchPoha();
  };

  return (
    <div>
      <h2>Poha Management</h2>
      {pohaData.map((item) => (
        <div key={item.id} style={{ marginBottom: "20px" }}>
          <p><strong>{item.name}</strong></p>
          <p>Price: ₹{item.price}</p>
          <button onClick={() => setEditData(item)}>Edit</button>
          <button onClick={() => handleDelete(item.id)}>Delete</button>
        </div>
      ))}

      {editData && (
        <div>
          <h3>Update Poha</h3>
          <input
            type="text"
            value={editData.name}
            onChange={(e) => setEditData({ ...editData, name: e.target.value })}
          />
          <input
            type="number"
            value={editData.price}
            onChange={(e) => setEditData({ ...editData, price: e.target.value })}
          />
          <button onClick={handleUpdate}>Save</button>
        </div>
      )}
    </div>
  );
};

export default PohaManagement;
