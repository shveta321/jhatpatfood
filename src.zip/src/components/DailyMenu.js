import React, { useState, useEffect } from "react";

const PhotoUploader = () => {
  const [photo, setPhoto] = useState(null);
  const [uploadedPhotos, setUploadedPhotos] = useState([]);

  const handlePhotoChange = (e) => {
    setPhoto(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!photo) return alert("Please select a photo");

    const formData = new FormData();
    formData.append("photo", photo);

    try {
      const res = await fetch("http://localhost:3000/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      setUploadedPhotos((prev) => [...prev, data.filename]);
      alert("Photo uploaded successfully!");
      setPhoto(null);
    } catch (error) {
      console.error("Upload error:", error);
      alert("Error uploading photo");
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Upload Photo</h2>
      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <input type="file" accept="image/*" onChange={handlePhotoChange} required />
        <button type="submit" style={{ marginLeft: "10px" }}>Upload</button>
      </form>

      <div style={{ marginTop: "30px" }}>
        <h3>Uploaded Photos</h3>
        <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
          {uploadedPhotos.map((file, index) => (
            <img
              key={index}
              src={`http://localhost:3000/uploads/${file}`}
              alt="Uploaded"
              style={{ width: "200px", height: "150px", objectFit: "cover" }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default PhotoUploader;








//node js


// server.js

// const express = require("express");
// const multer = require("multer");
// const cors = require("cors");
// const path = require("path");

// const app = express();
// app.use(cors());
// app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// // Setup multer
// const storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null, "uploads/");
//   },
//   filename: function (req, file, cb) {
//     const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
//     cb(null, uniqueSuffix + path.extname(file.originalname));
//   },
// });
// const upload = multer({ storage });

// // POST route to upload image
// app.post("/upload", upload.single("photo"), (req, res) => {
//   res.json({ filename: req.file.filename });
// });

// // Start server
// app.listen(5000, () => {
//   console.log("Server running on http://localhost:5000");
// });
