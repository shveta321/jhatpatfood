import React, { useEffect, useState } from "react";


const DailyMenu = () => {
  const [photo, setPhoto] = useState(null);

  useEffect(() => {
    const fetchMenu = async () => {
      const res = await fetch("http://localhost:5000/todaymenu");
      const data = await res.json();
      setPhoto(data.filename);
    };

    fetchMenu();
  }, []);

  return (
    <div style={{ textAlign: "center", marginTop: "20px" }}>
      <h2>Today's Menu</h2>
      {photo ? (
        <img
          src={`http://localhost:5000/uploads/${photo}`}
          alt="Today's Menu"
          style={{ width: "400px", height: "auto", borderRadius: "10px" }}
        />
      ) : (
        <p>No menu uploaded today.</p>
      )}
    </div>
  );
};

export default DailyMenu;
