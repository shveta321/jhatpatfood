import React, { useEffect, useState } from "react";


const DailyMenu = () => {
  const [photo, setPhoto] = useState(null);

  useEffect(() => {
    const fetchMenu = async () => {
      const res = await fetch("http://localhost:5000/todaymenu");
      const data = await res.json();
      setPhoto(data.filename);
    };

    fetchMenu();
  }, []);

  return (
    <div style={{ textAlign: "center", marginTop: "20px" }}>
      <h2>Today's Menu</h2>
      <div className="uplod-im">
        {photo ? (
          <img
            src={`http://localhost:5000/uploads/${photo}`}
            alt="Today's Menu"
            style={{ width: "454px", height: "auto", borderRadius: "10px",    border: "13px solid white", boxShadow: "0px 2px 4px 4px #dbd8d8"
 }}
          />
        ) : (
          <p>No menu uploaded today.</p>
        )}
      </div>

    </div>
  );
};

export default DailyMenu;
