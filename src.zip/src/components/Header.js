// import React from 'react';
import { Link } from 'react-router-dom';
// import { Link, Outlet } from 'react-router-dom';
import logo from '../img/JHATPAT_LOGO.png';

import React, { useState } from 'react';





function Header() {

    const [isDropdownOpen, setIsDropdownOpen] = useState(false);

    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };

    return (
        <>
            <header className="jhat-heade">
                <div className="head-log">
                    <div className="im85g-log">
                        <img src={logo} alt="Logo" width="95" />
                    </div>

                    <div className="nav-container">
                        <ul className="list-jha">
                            <li><Link to="/">Home</Link></li>
                            <li><Link to="/about">About</Link></li>
                            <li><Link to="/services">Service</Link></li>
                            <li><Link to="/event">Events</Link></li>


                            <li className="dropdown" onClick={toggleDropdown}>
                                <span className="dropbtn">Menu</span>
                                <div className={`dropdown-content ${isDropdownOpen ? 'show' : ''}`}>
                                    <a href="/menu/breakfast" target="_blank" rel="noopener noreferrer">
                                        Breakfast
                                    </a>
                                    <Link to="/menu/lunch">Lunch</Link>
                                    <Link to="/menu/dinner">Dinner</Link>
                                </div>
                            </li>



                            {/* <div className="dropdown-menu">
                            <ul>
                                <li>
                                    <a href="/userProfile">My Profile</a>
                                </li> 
                                <li onClick={handleLogout} className="logout-button">
                                    Logout
                                </li> 
                            </ul>
                        </div> */}

                            <li><Link to="/pages">Pages</Link></li>
                            <li><Link to="/contact">Contact</Link></li>
                        </ul>
                    </div>

                    <button className="search-btn">
                        <i className="fas fa-search"></i>
                    </button>
                </div>
            </header>
        </>
    );
}

export default Header;
