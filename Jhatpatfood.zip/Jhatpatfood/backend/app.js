const express = require('express');
const mysql = require('mysql');

const app = express();
const PORT = 3000;

// ✅ MySQL connection
const connection = mysql.createConnection({
  host: '127.0.0.1',     // ← ye line important hai
  user: 'root',
  password: '',          // ← agar tumne password lagaya ho to yahan daalo
  database: 'jhatpatfood', // ← apna database ka naam daalo
  port: 3307
});

// ✅ Connect to MySQL
connection.connect((error) => {
  if (error) {
    console.error('Database connection failed:', error);
    return;
  }
  console.log('Database connected successfully!');
});

// ✅ Example route
app.get('/', (req, res) => {
  res.send('JhatpatFood backend is running!');
});

// ✅ Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
